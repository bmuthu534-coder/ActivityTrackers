let activities = JSON.parse(localStorage.getItem("activities")) || [];

// Elements
const list = document.getElementById("activityList");
const progressText = document.getElementById("progress");
const input = document.getElementById("activityInput");

// Save to Local Storage
function saveData() {
  localStorage.setItem("activities", JSON.stringify(activities));
}

// Render
function renderActivities() {
  list.innerHTML = "";

  activities.forEach(activity => {
    const li = document.createElement("li");

    if (activity.completed) li.classList.add("completed");

    li.innerHTML = `
      <span>${activity.name}</span>
      <div class="actions">
        <button onclick="toggleActivity(${activity.id})">
          ${activity.completed ? "✔" : "Done"}
        </button>
        <button onclick="deleteActivity(${activity.id})">❌</button>
      </div>
    `;

    list.appendChild(li);
  });

  updateProgress();
  saveData();
}

// Add Activity
function addActivity() {
  const name = input.value.trim();
  if (!name) return alert("Enter activity!");

  activities.push({
    id: Date.now(),
    name,
    completed: false
  });

  input.value = "";
  renderActivities();
}

// Toggle Complete
function toggleActivity(id) {
  activities = activities.map(a =>
    a.id === id ? { ...a, completed: !a.completed } : a
  );
  renderActivities();
}

// Delete
function deleteActivity(id) {
  activities = activities.filter(a => a.id !== id);
  renderActivities();
}

// Progress
function updateProgress() {
  const completed = activities.filter(a => a.completed).length;
  const total = activities.length;

  progressText.textContent = `${completed} / ${total} completed`;

  if (total && completed === total) {
    progressText.textContent += " 🎉 All Done!";
  }
}

// Dark Mode
function toggleDarkMode() {
  document.body.classList.toggle("dark");
}

// Init
renderActivities();